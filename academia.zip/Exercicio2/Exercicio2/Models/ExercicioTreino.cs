﻿namespace Exercicio2.Models
{
    public class ExercicioTreino
    {
        public int ExercicioId { get; set; }
        public Exercicio Exercicio { get; set; }

        public int TreinoId { get; set; }
        public Treino Treino { get; set; }
    }
}
