﻿using Microsoft.EntityFrameworkCore;
using Exercicio2.Models;

namespace Exercicio2.Models
{
    public class Context : DbContext
    {
        public Context(DbContextOptions<Context> options) : base(options)
        {
        }

        public DbSet<Aluno> Alunos { get; set; }
        public DbSet<Exercicio> Exercicios { get; set; }
        public DbSet<Personal> Personais { get; set; }
        public DbSet<Treino> Treinos { get; set; }
        public DbSet<ExercicioTreino> ExerciciosTreinos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ExercicioTreino>()
                .HasKey(et => new { et.ExercicioId, et.TreinoId });

            modelBuilder.Entity<ExercicioTreino>()
                .HasOne(et => et.Exercicio)
                .WithMany(e => e.ExerciciosTreinos)
                .HasForeignKey(et => et.ExercicioId);

            modelBuilder.Entity<ExercicioTreino>()
                .HasOne(et => et.Treino)
                .WithMany(t => t.ExerciciosTreinos)
                .HasForeignKey(et => et.TreinoId);
        }
    }
}
