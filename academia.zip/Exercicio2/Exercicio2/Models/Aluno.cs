﻿namespace Exercicio2.Models
{
    public class Aluno
    {
        public int AlunoId { get; set; }
        public string Nome { get; set; }
        public DateTime Data_Nascimento { get; set; }
        public string Email { get; set; }
        public string Instagram { get; set; }
        public string Telefone { get; set; }
        public int PersonalID { get; set; }
        public string Observacoes { get; set; }

        public ICollection<Treino> Treinos { get; set; }
    }
}
