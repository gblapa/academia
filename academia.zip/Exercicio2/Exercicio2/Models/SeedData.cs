﻿
using Exercicio2.Models;
using Microsoft.EntityFrameworkCore;

namespace AtividadeAcademia.Models
{
    public class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            //associa os dados ao contexto
            Context context = app.ApplicationServices.GetService<Context>();

            //inserir os dados nas entradas do contexto
            context.Database.Migrate();

            //se o contexto estiver vazio
            if (!context.Alunos.Any()) //inserir os dados dos produtos e fabricantes
            {
                context.Alunos.AddRange(
                    new Aluno { Nome = "Alice Ávila", Data_Nascimento = new DateTime(2003, 4, 10), Email = "alice171@gmail.com", Instagram = "alicee", Telefone = "35 98876654", PersonalID = 1, Observacoes = "Escoliose" },
                    new Aluno { Nome = "Alice Ávila", Data_Nascimento = new DateTime(1999, 9, 11), Email = "dudinha157@gmail.com", Instagram = "dudao", Telefone = "35 98876564", PersonalID = 3, Observacoes = "Marca passo" },
                   new Aluno { Nome = "Vinicius Jacinto", Data_Nascimento = new DateTime(2003, 4, 11), Email = "vinicius34@gmail.com", Instagram = "vividacaca", Telefone = "35 987656654", PersonalID = 2, Observacoes = "mão quebrada" });

                context.Personais.AddRange(
                    new Personal { Nome = "Joaquim", Especialidades = "Funcional" },
                    new Personal { Nome = "Franciele", Especialidades = "Musculação" },
                    new Personal { Nome = "Marcio", Especialidades = "Dança" },
                    new Personal { Nome = "Celso", Especialidades = "Crossfit" },
                    new Personal { Nome = "Jaqueline", Especialidades = "Yoga" });

                context.Treinos.AddRange(
                    new Treino { PersonalId = 1, AlunoId = 1, Data = new DateTime(2024, 3, 30).Add(new TimeSpan(14, 0, 0)) },
                    new Treino { PersonalId = 2, AlunoId = 2, Data = new DateTime(2024, 5, 10).Add(new TimeSpan(13, 3, 0)) });

                context.Exercicios.AddRange(
                    new Exercicio { Nome = "Elevação pelvica", Categoria = "Gluteo", Descrição = "Fortalecer os gluteos" });
                context.SaveChanges();
            }
        }
    }
}
