﻿namespace Exercicio2.Models
{
    public class Exercicio
    {
        public int ExercicioId { get; set; }
        public string Nome { get; set; }
        public string Categoria { get; set; }
        public string Descrição { get; set; }
        public ICollection<ExercicioTreino> ExerciciosTreinos { get; set; }
    }
}

