﻿namespace Exercicio2.Models
{
    public class Personal
    {
        public int PersonalId { get; set; }
        public string Nome { get; set; }
        public string Especialidades { get; set; }
        public ICollection<Treino> Treinos { get; set; }

    }
}

